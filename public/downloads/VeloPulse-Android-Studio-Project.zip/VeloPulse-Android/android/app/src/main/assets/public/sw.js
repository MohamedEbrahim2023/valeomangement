/**
 * Copyright 2018 Google Inc. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *     http://www.apache.org/licenses/LICENSE-2.0
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

// If the loader is already loaded, just stop.
if (!self.define) {
  let registry = {};

  // Used for `eval` and `importScripts` where we can't get script URL by other means.
  // In both cases, it's safe to use a global var because those functions are synchronous.
  let nextDefineUri;

  const singleRequire = (uri, parentUri) => {
    uri = new URL(uri + ".js", parentUri).href;
    return registry[uri] || (
      
        new Promise(resolve => {
          if ("document" in self) {
            const script = document.createElement("script");
            script.src = uri;
            script.onload = resolve;
            document.head.appendChild(script);
          } else {
            nextDefineUri = uri;
            importScripts(uri);
            resolve();
          }
        })
      
      .then(() => {
        let promise = registry[uri];
        if (!promise) {
          throw new Error(`Module ${uri} didn’t register its module`);
        }
        return promise;
      })
    );
  };

  self.define = (depsNames, factory) => {
    const uri = nextDefineUri || ("document" in self ? document.currentScript.src : "") || location.href;
    if (registry[uri]) {
      // Module is already loading or loaded.
      return;
    }
    let exports = {};
    const require = depUri => singleRequire(depUri, uri);
    const specialDeps = {
      module: { uri },
      exports,
      require
    };
    registry[uri] = Promise.all(depsNames.map(
      depName => specialDeps[depName] || require(depName)
    )).then(deps => {
      factory(...deps);
      return exports;
    });
  };
}
define(['./workbox-afac4cd2'], (function (workbox) { 'use strict';

  self.skipWaiting();
  workbox.clientsClaim();
  /**
   * The precacheAndRoute() method efficiently caches and responds to
   * requests for URLs in the manifest.
   * See https://goo.gl/S9QRab
   */
  workbox.precacheAndRoute([{
    "url": "registerSW.js",
    "revision": "1872c500de691dce40960bb85481de07"
  }, {
    "url": "pwa-maskable-512x512.png",
    "revision": "d46a8b74deb68486b457323b1300d2be"
  }, {
    "url": "pwa-512x512.png",
    "revision": "776524d2f912bb4a8bbb9f1409942a00"
  }, {
    "url": "pwa-192x192.png",
    "revision": "1ac13304e7d3c5ec0b5e16ad47b3bc6f"
  }, {
    "url": "index.html",
    "revision": "109aaeb4c61b0ec08cdda9ce0281f875"
  }, {
    "url": "icon.svg",
    "revision": "9fb893f82da1374a5f03e7612ff49eb4"
  }, {
    "url": "apple-touch-icon.png",
    "revision": "d2328473919c6a34c6a43cfcbf04d6e9"
  }, {
    "url": "assets/vendor-react-D-DGwbc5.js",
    "revision": null
  }, {
    "url": "assets/vendor-icons-C3gK4PTc.js",
    "revision": null
  }, {
    "url": "assets/vendor-charts-DmAKmI78.js",
    "revision": null
  }, {
    "url": "assets/rolldown-runtime-XKyaHtl9.js",
    "revision": null
  }, {
    "url": "assets/index-C30mgglH.css",
    "revision": null
  }, {
    "url": "assets/index-BRUgp6D-.js",
    "revision": null
  }, {
    "url": "apple-touch-icon.png",
    "revision": "d2328473919c6a34c6a43cfcbf04d6e9"
  }, {
    "url": "icon.svg",
    "revision": "9fb893f82da1374a5f03e7612ff49eb4"
  }, {
    "url": "pwa-192x192.png",
    "revision": "1ac13304e7d3c5ec0b5e16ad47b3bc6f"
  }, {
    "url": "pwa-512x512.png",
    "revision": "776524d2f912bb4a8bbb9f1409942a00"
  }, {
    "url": "pwa-maskable-512x512.png",
    "revision": "d46a8b74deb68486b457323b1300d2be"
  }, {
    "url": "manifest.webmanifest",
    "revision": "ec91ac829683889f2df3a1414378d991"
  }], {});
  workbox.cleanupOutdatedCaches();
  workbox.registerRoute(new workbox.NavigationRoute(workbox.createHandlerBoundToURL("index.html"), {
    denylist: [/^\/api\//]
  }));
  workbox.registerRoute(/^https:\/\/fonts\.googleapis\.com\/.*/i, new workbox.CacheFirst({
    "cacheName": "google-fonts-cache",
    plugins: [new workbox.ExpirationPlugin({
      maxEntries: 10,
      maxAgeSeconds: 31536000
    }), new workbox.CacheableResponsePlugin({
      statuses: [0, 200]
    })]
  }), 'GET');
  workbox.registerRoute(/^https:\/\/fonts\.gstatic\.com\/.*/i, new workbox.CacheFirst({
    "cacheName": "gstatic-fonts-cache",
    plugins: [new workbox.ExpirationPlugin({
      maxEntries: 10,
      maxAgeSeconds: 31536000
    }), new workbox.CacheableResponsePlugin({
      statuses: [0, 200]
    })]
  }), 'GET');

}));
